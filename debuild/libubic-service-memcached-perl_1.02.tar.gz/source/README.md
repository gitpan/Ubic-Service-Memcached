Ubic-Service-Memcached
===========================

Ubic::Service::Memcached allows you to run memcached using ubic.
